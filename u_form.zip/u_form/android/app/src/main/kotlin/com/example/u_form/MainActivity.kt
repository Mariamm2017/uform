package com.example.u_form

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
